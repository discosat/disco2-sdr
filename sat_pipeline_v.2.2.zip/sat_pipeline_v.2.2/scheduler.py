#!/usr/bin/env python3
"""Unattended AOS/LOS scheduler: record each pass, then analyse it immediately.

Watches a satellite's elevation using the TLE and ground station from
config.toml, and around each pass:

  AOS: starts rigctld, then launches recorder/record_pass.py as its own
       subprocess (one process per pass — if a pass's recording ever hangs
       or crashes, it can't affect the next one).
  LOS: stops the recorder and rigctld, finds the recording that just landed
       in raw_data_dir, and immediately runs it through the doppler_tle
       analysis pipeline. Results land in output_dir.

Everything is driven by config.toml (TLE, ground station, min elevation,
recorder settings, analysis parameters) — there is nothing satellite- or
station-specific hardcoded here. The TLE is refreshed from CelesTrak once a
day (or read from a manual file) by doppler_tle/tle_source.py; see [tle].

Run it as a long-lived background process (e.g. via systemd) on the machine
that also runs Gpredict, connected to the same rigctld port:

    python scheduler.py                  # uses ./config.toml
    python scheduler.py /path/to/config.toml
"""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
import tomllib
from dataclasses import replace
from datetime import datetime, time as dtime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from skyfield.api import EarthSatellite, load, wgs84

PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from doppler_tle import config as doppler_config  # noqa: E402
from doppler_tle import pipeline as doppler_pipeline  # noqa: E402
from doppler_tle.tle_source import TleSource  # noqa: E402

RECORDER_DIR = PROJECT_ROOT / "recorder"
RECORD_PASS = RECORDER_DIR / "record_pass.py"

# A pass starts when the satellite rises above this and ends when it drops below.
MIN_ELEVATION_DEG = 0.5

HEARTBEAT_INTERVAL_S = 600  # log a liveness line at most this often while idle
TLE_CHECK_INTERVAL_S = 600  # how often to ask TleSource for a new TLE (it only
                            # downloads when the cached copy is older than
                            # [tle] refresh_hours; in manual mode this picks up
                            # edits to the TLE file without a restart)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

class SchedulerSettings:
    """The [recorder] / [scheduler] sections — not part of doppler_tle's Config."""

    def __init__(self, data: dict):
        rec = data.get("recorder", {})
        sch = data.get("scheduler", {})
        self.samp_rate = int(rec.get("samp_rate", 500_000))
        self.gain = float(rec.get("gain", 55))
        self.antenna = str(rec.get("antenna", "TX/RX"))
        self.rigctld_host = str(rec.get("rigctld_host", "127.0.0.1"))
        self.rigctld_port = int(rec.get("rigctld_port", 7356))
        self.rigctld_cmd = list(rec.get("rigctld_cmd", ["rigctld", "-m", "1", "-t", "7356"]))
        self.check_interval_s = float(sch.get("check_interval_s", 2))

        tz_name = str(sch.get("timezone", "Europe/Copenhagen"))
        try:
            self.tz = ZoneInfo(tz_name)
        except Exception as e:  # noqa: BLE001
            sys.exit(f"ERROR: [scheduler] timezone {tz_name!r} is not a valid time zone name "
                     f"(use e.g. \"Europe/Copenhagen\"): {e}")
        self.tz_name = tz_name

        # Recording windows: [window1], [window2]. (name, enabled, start, end)
        self.windows: list[tuple[str, bool, dtime, dtime]] = []
        for name in ("window1", "window2"):
            w = data.get(name, {})
            enabled = w.get("enabled", False)
            if not isinstance(enabled, bool):
                sys.exit(f"ERROR: [{name}] enabled must be true or false, not {enabled!r}")
            start = _parse_hhmm(name, "start", w.get("start", "00:00"))
            end = _parse_hhmm(name, "end", w.get("end", "00:00"))
            if enabled and start == end:
                sys.exit(f"ERROR: [{name}] start and end are both {w.get('start')}; "
                         f"use different times")
            self.windows.append((name, enabled, start, end))

    def active_window(self, now_local: datetime) -> str | None:
        """Name of the enabled window containing ``now_local``, else None.
        A window may cross midnight (e.g. 22:00 -> 02:00)."""
        t = now_local.time()
        for name, enabled, start, end in self.windows:
            if not enabled:
                continue
            inside = (start <= t < end) if start < end else (t >= start or t < end)
            if inside:
                return name
        return None

    def describe_windows(self) -> str:
        parts = [f"{n}: {s:%H:%M}-{e:%H:%M}" if en else f"{n}: off"
                 for n, en, s, e in self.windows]
        return ", ".join(parts) + f" ({self.tz_name})"


def _parse_hhmm(section: str, key: str, value) -> dtime:
    try:
        h, m = str(value).split(":")
        return dtime(int(h), int(m))
    except (ValueError, TypeError):
        sys.exit(f"ERROR: [{section}] {key} must look like \"HH:MM\" (24 h), not {value!r}")


def _resolve(base_dir: Path, value: str) -> Path:
    p = Path(value)
    return p if p.is_absolute() else (base_dir / p)


def load_all_config(config_path: Path) -> tuple[doppler_config.Config, SchedulerSettings, Path]:
    """Load config.toml into (doppler_tle Config, SchedulerSettings, raw_data_dir).

    Paths are resolved against config_path's directory, not the current
    working directory, so this works when launched from anywhere (e.g. by
    systemd with an arbitrary WorkingDirectory).
    """
    with config_path.open("rb") as f:
        raw = tomllib.load(f)
    base_dir = config_path.parent

    # load_config already resolves the [tle] paths against the config file's
    # directory; output_dir is resolved here.
    cfg = doppler_config.load_config(config_path)
    if cfg.output_dir:
        cfg.output_dir = str(_resolve(base_dir, cfg.output_dir))

    settings = SchedulerSettings(raw)
    raw_data_dir = _resolve(base_dir, raw.get("recording", {}).get("raw_data_dir", "Raw_Data"))

    return cfg, settings, raw_data_dir


# ---------------------------------------------------------------------------
# Filenames
# ---------------------------------------------------------------------------

def build_raw_filename(raw_data_dir: Path, carrier_hz: int, samp_rate: int) -> Path:
    """gqrx_<date>_<time>_<carrier>_<rate>_fc.raw, timestamped in UTC.

    UTC matters here: doppler_tle.dsp.parse_gqrx_filename interprets the
    embedded date/time as UTC, so the filename must be built in UTC too,
    regardless of the recording machine's local timezone.
    """
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    return raw_data_dir / f"gqrx_{stamp}_{carrier_hz}_{samp_rate}_fc.raw"


def freq_log_path_for(raw_path: Path) -> Path:
    """Matches doppler_tle/pipeline.py's _stem(): strips only the '.raw' suffix."""
    return raw_path.with_name(raw_path.name[: -len(".raw")] + "_freqlog.csv")


def discover_latest_recording(raw_data_dir: Path) -> Path | None:
    """The 'automatically search the folder' step: newest *_fc.raw file."""
    candidates = sorted(raw_data_dir.glob("*_fc.raw"), key=lambda p: p.stat().st_mtime)
    return candidates[-1] if candidates else None


# ---------------------------------------------------------------------------
# Pass decision
# ---------------------------------------------------------------------------

def decide(above: bool, recording: bool, skipping: bool, in_window: bool) -> tuple[str, bool]:
    """What to do this tick -> (action, skipping).

    action is "start", "stop", "skip" (a pass began outside every window, so it
    is ignored) or "none". A pass is recorded in full if it *begins* inside an
    enabled window, even when it runs past the window's end; a pass that was
    already under way when a window opens is not picked up halfway.
    """
    if not above:
        return ("stop" if recording else "none"), False
    if recording:
        return "none", False
    if skipping:
        return "none", True
    return ("start", False) if in_window else ("skip", True)


# ---------------------------------------------------------------------------
# Process management
# ---------------------------------------------------------------------------

def _stop(proc: subprocess.Popen | None, name: str, timeout: float) -> None:
    if proc is None or proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        _log(f"{name} didn't stop within {timeout:.0f}s, killing it")
        proc.kill()
        proc.wait()


def _log(msg: str) -> None:
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    print(f"[{stamp}] {msg}", flush=True)


# ---------------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------------

def analyse(cfg: doppler_config.Config, raw_path: Path) -> None:
    """Run the doppler_tle pipeline on raw_path, without taking the daemon down
    if this particular pass's analysis fails."""
    run_cfg = replace(cfg, input=str(raw_path))
    try:
        doppler_config.validate(run_cfg)
        doppler_pipeline.run(run_cfg, show=False)
    except SystemExit as e:
        _log(f"analysis aborted: {e}")
    except Exception as e:  # noqa: BLE001 — a bad pass must not kill the daemon
        _log(f"analysis failed: {e!r}")


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

def main() -> None:
    config_path = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else PROJECT_ROOT / "config.toml"
    cfg, settings, raw_data_dir = load_all_config(config_path)
    raw_data_dir.mkdir(parents=True, exist_ok=True)

    tle_source = TleSource.from_config(cfg, log=_log)
    name, l1, l2 = tle_source.get()   # downloads on first start if there is no cached copy
    ts = load.timescale()
    sat = EarthSatellite(l1, l2, name, ts)
    ground_station = wgs84.latlon(cfg.gs_latitude, cfg.gs_longitude, elevation_m=cfg.gs_elevation_m)
    carrier_hz = int(round(cfg.transmit_freq_mhz * 1e6))

    state = {"rigctld_proc": None, "recorder_proc": None, "recording": False}

    def shutdown(*_args) -> None:
        _log("shutting down…")
        _stop(state["recorder_proc"], "recorder", timeout=10)
        _stop(state["rigctld_proc"], "rigctld", timeout=5)
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    _log(f"scheduler started, watching {name} "
         f"(recording windows {settings.describe_windows()}, "
         f"raw_data_dir={raw_data_dir}, output_dir={cfg.output_dir})")

    if not any(w[1] for w in settings.windows):
        _log("WARNING: both recording windows are disabled - nothing will be recorded. "
             "Set enabled = true in [window1] or [window2].")

    last_heartbeat = 0.0
    skipping = False   # current pass began outside every window
    next_tle_check = time.monotonic() + TLE_CHECK_INTERVAL_S

    while True:
        sky_now = ts.now()
        alt, az, distance = (sat - ground_station).at(sky_now).altaz()
        elevation = alt.degrees

        # Pick up a newer TLE (daily download in auto mode, or an edited file in
        # manual mode). Never during a pass or while the satellite is up: a
        # download can block for several seconds and must not delay AOS/LOS, and
        # the orbit shouldn't change under a recording in progress.
        if (not state["recording"] and elevation < MIN_ELEVATION_DEG
                and time.monotonic() >= next_tle_check):
            next_tle_check = time.monotonic() + TLE_CHECK_INTERVAL_S
            try:
                new_name, new_l1, new_l2 = tle_source.get()
            except Exception as e:  # noqa: BLE001 — keep running on the TLE we have
                _log(f"TLE refresh failed, keeping the current TLE: {e!r}")
            else:
                if (new_l1, new_l2) != (l1, l2):
                    name, l1, l2 = new_name, new_l1, new_l2
                    sat = EarthSatellite(l1, l2, name, ts)
                    _log(f"now tracking the updated TLE for {name}")

        window = settings.active_window(datetime.now(settings.tz))
        action, skipping = decide(elevation >= MIN_ELEVATION_DEG, state["recording"],
                                  skipping, window is not None)

        if action == "skip":
            _log(f"pass began at {elevation:.1f} deg outside the recording windows - not recording it")

        elif action == "start":
            raw_path = build_raw_filename(raw_data_dir, carrier_hz, settings.samp_rate)
            freq_log_path = freq_log_path_for(raw_path)
            _log(f"AOS - elevation {elevation:.1f} deg, in {window}, recording to {raw_path.name}")

            state["rigctld_proc"] = subprocess.Popen(settings.rigctld_cmd)
            time.sleep(2)  # give rigctld a moment to bind the port

            env = os.environ.copy()
            env["SAT_IQ_FILENAME"] = str(raw_path)
            env["SAT_FREQ_LOG_FILENAME"] = str(freq_log_path)
            env["SAT_SAMP_RATE"] = str(settings.samp_rate)
            env["SAT_GAIN"] = str(settings.gain)
            env["SAT_ANTENNA"] = settings.antenna
            env["SAT_RIGCTLD_HOST"] = settings.rigctld_host
            env["SAT_RIGCTLD_PORT"] = str(settings.rigctld_port)
            state["recorder_proc"] = subprocess.Popen(
                [sys.executable, str(RECORD_PASS)], env=env, cwd=str(RECORDER_DIR))
            state["recording"] = True

        elif action == "stop":
            _log(f"LOS - elevation {elevation:.1f} deg, stopping capture")
            _stop(state["recorder_proc"], "recorder", timeout=10)
            _stop(state["rigctld_proc"], "rigctld", timeout=5)
            state["recorder_proc"] = state["rigctld_proc"] = None
            state["recording"] = False

            raw_path = discover_latest_recording(raw_data_dir)
            if raw_path is None:
                _log(f"no recording found in {raw_data_dir}, skipping analysis")
            else:
                _log(f"analysing {raw_path.name}")
                analyse(cfg, raw_path)
                _log("analysis complete")

        elif not state["recording"] and (time.time() - last_heartbeat) >= HEARTBEAT_INTERVAL_S:
            _log(f"watching — current elevation {elevation:.1f} deg")
            last_heartbeat = time.time()

        time.sleep(settings.check_interval_s)


if __name__ == "__main__":
    main()
