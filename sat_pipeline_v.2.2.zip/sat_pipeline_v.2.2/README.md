# Satellite pass pipeline: record → analyse, unattended

Merges `Automatize_GNU_radio_control` (records a satellite pass with GNU
Radio, retuning the SDR live to track Doppler shift via Gpredict/rigctld)
and `doppler_tle` (fits a TLE to the Doppler curve of a recording) into one
unattended pipeline: watch for a pass, record it, and analyse it immediately
once it's over — no manual steps in between.

```
scheduler.py  (long-running daemon)
  │
  ├─ AOS ──► rigctld + recorder/record_pass.py
  │            (drives recorder/sat_iq_recorder.py, logs every Doppler
  │             retune to a CSV sidecar)
  │
  ├─ LOS ──► stop recording
  │
  └────────► doppler_tle pipeline, in-process
               (decimate → spectrogram → doppler → fit)
               reconstructing the true Doppler curve from the residual +
               freq log (doppler_tle/freqlog.py), then fitting the TLE

Everything is driven by config.toml. Results land in output_dir.
```

## Setup

```bash
conda env create -f environment.yml
conda activate sat-pipeline
```

Edit `config.toml` — in particular `[ground_station]`, `[tle]`, and
`transmit_freq_mhz` if you ever point this at a different satellite/station.
Every path in it (`raw_data_dir`, `output_dir`, `tle.path`) is resolved
relative to `config.toml`'s own location, not the current directory, so the
daemon can be launched from anywhere.

## Running it

```bash
python scheduler.py                    # uses ./config.toml
python scheduler.py /path/to/config.toml
```

**Gpredict must already be running and pointed at the same rigctld port
(default 7356) before AOS.** The recorder polls rigctld for a live
Doppler-corrected frequency, but doesn't start Gpredict itself — that part
was true of the original setup too. If Gpredict isn't connected when a pass
starts, the SDR just stays at the nominal frequency for that pass (see
"Doppler retuning" below — this degrades gracefully rather than producing a
bad result).

### As a systemd service

```ini
[Unit]
Description=Satellite pass recorder + analyser
After=network.target

[Service]
Type=simple
WorkingDirectory=/path/to/this/project
ExecStart=/path/to/conda/envs/sat-pipeline/bin/python scheduler.py
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

## TLE: automatic daily update, or manual

The `[tle]` section of `config.toml` decides where the TLE comes from.

**`mode = "auto"` (default).** The scheduler downloads the latest TLE from
`url` (CelesTrak, DISCO-2 = catalogue number 68431) when it starts and then
again whenever its copy is older than `refresh_hours` (24). The download is
stored in `disco-2_celestrak.tle`, which is separate from your manual file, so
`disco-2.tle` is never overwritten. A download is only accepted if it is a
valid TLE (checksums, right catalogue number); otherwise the last good copy
stays in use and the download is retried after an hour. Only before the very
first successful download does the scheduler fall back to `disco-2.tle`. When
a new TLE arrives it is picked up between passes, never during one. The fit
stage (`doppler_tle`) reads from the same place, so recording and analysis use
the same TLE.

**`mode = "manual"`.** No network access at all; the TLE is read from `path`
(`disco-2.tle`). Paste a new TLE into that file whenever you like — the running
scheduler notices within ~10 minutes, no restart needed. To switch between
`auto` and `manual`, change `mode` and restart `scheduler.py`.

The scheduler logs which TLE it is using, with its epoch, and warns if it is
more than 14 days old. To check without starting the daemon:

```bash
python -m doppler_tle.tle_source -c config.toml            # print current TLE
python -m doppler_tle.tle_source -c config.toml --force    # download again now
```

**Gpredict is separate.** This only updates the TLE used by `scheduler.py`
(AOS/LOS timing and the TLE fit). Gpredict keeps its own TLE for the live
Doppler tuning, so enable its own automatic update from CelesTrak
(Edit → Update TLE data from network / Preferences → TLE) if you want that
kept current as well.

## Recording windows

`[window1]` and `[window2]` in `config.toml` say when passes are recorded
(night or day, it doesn't matter). Each has `enabled = true/false`, `start` and
`end` as 24 h `HH:MM` in `[scheduler] timezone` (`Europe/Copenhagen`, which
switches between CET and CEST by itself). A window may cross midnight.

- A pass is recorded if it **begins** (rises above 0.5°) inside an enabled
  window, and is then recorded **in full**, even if it ends after the window
  closes. This keeps the Doppler curve complete for the TLE fit.
- A pass that is already under way when a window opens is skipped.
- With both windows disabled nothing is recorded (the scheduler warns at start).
- `min_elevation_deg` no longer exists; a pass is simply the satellite above 0.5°.

## Versions

| Version | Change |
|---|---|
| v.2.2 | Recording windows (`[window1]`, `[window2]`); `min_elevation_deg` removed |
| v.2.1 | TLE downloaded daily from CelesTrak with manual mode; `tests/` removed |
| v.2.0 | Original |

### Analysing one file by hand

```bash
python -m doppler_tle -c config.toml -i Raw_Data/gqrx_..._fc.raw
```

## Doppler retuning during recording

The recorder keeps the SDR roughly centred on the downlink throughout a
pass by continuously retuning it to Gpredict's live Doppler prediction.
Every retune is logged to a `*_freqlog.csv` sidecar next to the recording.
Because of that retuning, what actually lands in the recorded IQ is a
*residual* — the difference between the true Doppler and whatever Gpredict
predicted — not the full Doppler curve. `doppler_tle/freqlog.py`
reconstructs the true curve from the residual and the freq log before
anything else happens (CSV, plots, and the TLE fit all see the corrected
curve). See that module's docstring for the exact formula.

Two things worth knowing:

- **If Gpredict isn't connected**, the freq log just stays flat, and the
  compensation formula reduces to a no-op — equivalent to a straightforward
  fixed-frequency recording. Nothing breaks, it just doesn't benefit from
  live tracking for that pass.
- **The decimated bandwidth needs headroom above the expected residual.**
  If Gpredict's TLE is badly stale, the residual can grow large enough to
  fall outside the decimated passband and get attenuated by the
  anti-aliasing filter, corrupting the reconstructed curve exactly where
  the correction error is largest. The current `[decimation]` settings give
  a decimated Nyquist of ~20.8 kHz against a typical residual of tens to a
  few hundred Hz, so this isn't a practical concern here — but if you ever
  narrow the decimation a lot, keep this in mind.

## Notes on the merge

- **`recorder/sat_iq_recorder.py` and `sat_iq_recorder.grc` have two deliberate
  changes: RX gain and RX antenna are now proper GRC variables** (`gain`,
  default 55 dB; `antenna`, default `TX/RX`) **instead of hardcoded/blank
  values**, so both can be set from `config.toml` the same way sample rate
  and rigctld settings already were. These are the only intentional
  exceptions to leaving the generated flowgraph alone — see the notes below.
  `sat_iq_recorder_doppler_ctrl_0.py` is still fully untouched. Everything
  else per-pass (filename, sample rate, rigctld host/port) is still applied
  through the flowgraph's generated setter methods from `record_pass.py`.
- **RX gain was hardcoded to 55 dB and wasn't configurable.** The flowgraph
  also calls `set_if_gain(20, 0)` and `set_bb_gain(20, 0)`, but for the UHD/B200
  backend those don't correspond to a real gain stage and are silently
  ignored (confirmed against gr-osmosdr's UHD source) — `set_gain()` is the
  only one that reaches the hardware, and it's the same stage GQRX's "PGA"
  slider controls. `gain` in `config.toml`'s `[recorder]` section now
  controls it directly; it's set to 65 dB to match the value already
  working in GQRX. Raise or lower it there if reception quality changes.
- **RX antenna was left as an empty string**, i.e. never explicitly chosen —
  the B200 has two RX-capable ports (`TX/RX` and `RX2`), and gr-osmosdr's own
  documentation notes that leaving this blank is only appropriate for
  single-antenna devices. `antenna` in `config.toml`'s `[recorder]` section
  now sets it explicitly to `TX/RX`, matching what's already known to work
  in GQRX (`RX2` reportedly had problems there). Change it there if you ever
  need to switch ports.
- **`doppler_tle/pipeline.py`** gained the freq-log compensation step in its
  `doppler` stage, plus a `freq_log` path in `Paths`/`resolve_paths()`.
  Everything else in that package (`dsp.py`, `doppler.py`, `tle.py`,
  `config.py`, `extract_gnu_doppler.py`) is unchanged.
- **Recording filenames are now built in UTC**, not local time. The
  original recorder used `time.strftime()` (local time) while
  `doppler_tle`'s filename parser assumes UTC; on a station whose system
  clock isn't set to UTC this would have silently offset every timestamp
  used in the fit. `scheduler.py` builds filenames with
  `datetime.now(timezone.utc)` to remove the ambiguity either way.
- **`elevation_m`** differed slightly between the two original projects (16m
  vs 18m for the same station). Unified to 16m (`doppler_tle`'s value) in
  `config.toml` — adjust if 18m was the more accurate figure.
- **The recorder's fallback frequency (437.075 MHz)**, used whenever
  rigctld hasn't supplied a live correction yet, is baked into
  `sat_iq_recorder.py` at construction time and can't be changed from
  outside it. It already matches this project's `transmit_freq_mhz`
  default, so this doesn't matter for the current setup — but if you ever
  point this at a different satellite, update `center_freq_default` in
  `sat_iq_recorder.grc` and regenerate.

