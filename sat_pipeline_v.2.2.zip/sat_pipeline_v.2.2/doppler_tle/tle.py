"""TLE handling: parse/format two-line elements and fit them to a Doppler curve.

The fit perturbs a chosen set of orbital parameters (e.g. epoch, RAAN) with
least-squares so the predicted Doppler curve matches the observed one.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np

C_KM_S = 299_792.458  # speed of light

# Absolute finite-difference step for each fittable parameter, in that
# parameter's own units. The optimiser perturbs a parameter by this much to
# measure its effect on the Doppler curve. Steps must be large enough to clear
# skyfield's numerical noise (otherwise the parameter looks inert and is never
# fitted) but small enough to stay locally linear. Crucially these are absolute,
# so a small-magnitude angle and a large-magnitude epoch each get a sane step.
_DIFF_STEP_ABS = {
    "epoch": 1e-4,                   # days (~8.6 s)
    "inclination": 1e-3,             # degrees
    "raan": 1e-3,                    # degrees
    "arg_of_perigee": 1e-3,          # degrees
    "mean_anomaly": 1e-3,            # degrees
    "eccentricity": 1e-7,            # unitless
    "mean_motion": 1e-6,             # revs/day
    "first_div_mean_motion": 1e-9,
    "second_div_mean_motion": 1e-12,
    "drag_term": 1e-6,
}


# ---------------------------------------------------------------------------
# File parsing
# ---------------------------------------------------------------------------

def load_tle(path: str | Path, index: int = 0) -> tuple[str, str, str]:
    """Return the ``index``-th ``(name, line1, line2)`` block from a TLE file."""
    with Path(path).open() as f:
        lines = [ln.rstrip() for ln in f if ln.strip()]
    blocks = _parse_blocks(lines)
    if not blocks:
        raise ValueError(f"No TLE blocks found in {path}")
    if index >= len(blocks):
        raise IndexError(f"TLE index {index} out of range ({len(blocks)} block(s) in {path})")
    return blocks[index]


def _parse_blocks(lines: list[str]) -> list[tuple[str, str, str]]:
    """Parse 2-line (no name) or 3-line (named) TLE blocks from text lines."""
    blocks, i = [], 0
    while i < len(lines):
        if lines[i].startswith("1 ") and i + 1 < len(lines) and lines[i + 1].startswith("2 "):
            blocks.append((lines[i][2:7].strip(), lines[i], lines[i + 1]))  # name = catalog id
            i += 2
        elif (i + 2 < len(lines)
              and lines[i + 1].startswith("1 ") and lines[i + 2].startswith("2 ")):
            blocks.append((lines[i], lines[i + 1], lines[i + 2]))
            i += 3
        else:
            i += 1
    return blocks


# ---------------------------------------------------------------------------
# dict <-> TLE string conversion
# ---------------------------------------------------------------------------

def _parse_exp(s: str) -> float:
    """Decode TLE's implied-decimal exponent format, e.g. ' 30838-3' → 0.00030838."""
    s = s.strip()
    if s in ("00000-0", "00000+0", ""):
        return 0.0
    for i in range(len(s) - 1, 0, -1):
        if s[i] in "+-":
            return float("0." + s[:i].strip()) * 10 ** int(s[i:])
    return 0.0


def _format_exp(val: float) -> str:
    """Encode a float into TLE's 8-char implied-decimal exponent field.

    Layout: sign + 5 mantissa digits + exponent sign + 1 exponent digit, e.g.
    ``0.00045617`` → ``' 45617-3'`` (= 0.45617 × 10⁻³).
    """
    if val == 0.0:
        return " 00000+0"
    exp = int(math.floor(math.log10(abs(val)))) + 1
    mantissa = int(round(abs(val) * 10 ** (5 - exp)))
    sign = "-" if val < 0 else " "
    return f"{sign}{mantissa:05d}{exp:+d}"


def tle_to_dict(name: str, l1: str, l2: str) -> dict:
    """Parse the two TLE lines into a dict of orbital parameters."""
    return {
        "name": name,
        "satellite_number": int(l1[2:7]),
        "classification": l1[7],
        "launch_designator": l1[9:17].strip(),
        "epoch": float(l1[18:32]),
        "first_div_mean_motion": float(l1[33:43]),
        "second_div_mean_motion": _parse_exp(l1[44:52]),
        "drag_term": _parse_exp(l1[53:61]),
        "ephemeris_type": int(l1[62]),
        "element_set_number": int(l1[64:68]),
        "inclination": float(l2[8:16]),
        "raan": float(l2[17:25]),
        "eccentricity": float("0." + l2[26:33]),
        "arg_of_perigee": float(l2[34:42]),
        "mean_anomaly": float(l2[43:51]),
        "mean_motion": float(l2[52:63]),
        "revolution_number": int(l2[63:68]),
    }


def dict_to_tle(d: dict) -> tuple[str, str]:
    """Render a parameter dict back into two TLE lines (checksum byte left as 0)."""
    first_div = f"{d['first_div_mean_motion']:10.8f}".replace("0.", " .")
    ecc = f"{int(round(d['eccentricity'] * 1e7)):07d}"
    l1 = (f"1 {d['satellite_number']:05d}{d['classification']} "
          f"{d['launch_designator']:<8s} {d['epoch']:014.8f} "
          f"{first_div} {_format_exp(d['second_div_mean_motion'])} "
          f"{_format_exp(d['drag_term'])} {d['ephemeris_type']:1d} "
          f"{d['element_set_number']:4d}0")
    l2 = (f"2 {d['satellite_number']:05d} {d['inclination']:8.4f} {d['raan']:8.4f} "
          f"{ecc} {d['arg_of_perigee']:8.4f} {d['mean_anomaly']:8.4f} "
          f"{d['mean_motion']:11.8f}{d['revolution_number']:5d}0")
    return l1, l2


# ---------------------------------------------------------------------------
# Doppler prediction & fitting
# ---------------------------------------------------------------------------

def predict_doppler(l1: str, l2: str, gs, ts, unix_timestamps: np.ndarray,
                    carrier_freq_hz: float) -> np.ndarray:
    """Predicted Doppler shift (Hz) of ``carrier_freq_hz`` seen from ground station ``gs``."""
    from skyfield.api import EarthSatellite

    sat = EarthSatellite(l1, l2, ts=ts)
    times = ts.ut1(jd=unix_timestamps / 86400.0 + 2440587.5)
    topocentric = (sat - gs).at(times)
    _, _, distance = topocentric.altaz()

    pos_unit = topocentric.position.km / distance.km
    range_rate = (pos_unit * topocentric.velocity.km_per_s).sum(axis=0)
    return -carrier_freq_hz * range_rate / C_KM_S


@dataclass
class FitResult:
    name: str
    param_names: list[str]
    initial_params: np.ndarray
    fitted_params: np.ndarray
    initial_curve: np.ndarray      # predicted Doppler before the fit
    fitted_curve: np.ndarray       # predicted Doppler after the fit
    initial_cost: float
    final_cost: float
    success: bool
    message: str
    fitted_l1: str
    fitted_l2: str


def fit_tle(name: str, l1: str, l2: str, param_names: list[str], gs, ts,
            unix_timestamps: np.ndarray, doppler_obs: np.ndarray,
            carrier_freq_hz: float) -> FitResult:
    """Least-squares fit of ``param_names`` so the predicted Doppler matches ``doppler_obs``."""
    from scipy.optimize import least_squares

    base = tle_to_dict(name, l1, l2)

    def predict(params: np.ndarray) -> np.ndarray:
        d = dict(base)
        d.update(zip(param_names, params))
        pl1, pl2 = dict_to_tle(d)
        return predict_doppler(pl1, pl2, gs, ts, unix_timestamps, carrier_freq_hz)

    x0 = np.array([base[p] for p in param_names], dtype=float)
    initial_curve = predict(x0)

    # scipy's finite-difference step is *relative* to each value, so convert our
    # absolute per-parameter steps and scale the trust region to match. Without
    # this, large-magnitude parameters (e.g. epoch ~26000) drown out small ones
    # (e.g. raan ~80), which then never get fitted.
    diff_step = np.array([_DIFF_STEP_ABS.get(p, 1e-6) / max(1.0, abs(v))
                          for p, v in zip(param_names, x0)])
    result = least_squares(
        lambda p: doppler_obs - predict(p), x0=x0,
        diff_step=diff_step, x_scale=np.maximum(np.abs(x0), 1.0),
    )

    fitted = dict(base)
    fitted.update(zip(param_names, result.x))
    fitted_l1, fitted_l2 = dict_to_tle(fitted)
    fitted_curve = predict(result.x)

    return FitResult(
        name=name, param_names=list(param_names), initial_params=x0, fitted_params=result.x,
        initial_curve=initial_curve, fitted_curve=fitted_curve,
        initial_cost=float(np.sum((doppler_obs - initial_curve) ** 2)),
        final_cost=float(np.sum(result.fun ** 2)),
        success=bool(result.success), message=str(result.message),
        fitted_l1=fitted_l1, fitted_l2=fitted_l2,
    )


def _find_zero_crossing(t: np.ndarray, y: np.ndarray) -> float | None:
    """Return the time (s) at which *y* crosses zero, interpolated linearly.

    If the curve crosses zero more than once the crossing closest to the
    midpoint of the time axis is returned (the primary closest-approach point).
    Returns ``None`` if no zero crossing exists within the array.
    """
    sign_changes = np.where(np.diff(np.sign(y)))[0]
    if sign_changes.size == 0:
        return None

    # Interpolate each candidate crossing.
    crossings = []
    for i in sign_changes:
        # Linear interpolation: t_cross = t[i] - y[i] * dt / dy
        dt = t[i + 1] - t[i]
        dy = y[i + 1] - y[i]
        if dy == 0:
            continue
        t_cross = t[i] - y[i] * dt / dy
        crossings.append(t_cross)

    if not crossings:
        return None

    # Pick the crossing closest to the midpoint of the observation window.
    mid = (t[0] + t[-1]) / 2.0
    return min(crossings, key=lambda tc: abs(tc - mid))


def offset_measurement(t_rel: np.ndarray,
                       initial_curve: np.ndarray,
                       fitted_curve: np.ndarray) -> float | None:
    """Calculate the time offset (s) between the zero-crossings of the two curves.

    Finds the moment at which the fitted TLE Doppler curve crosses 0 Hz and
    the moment at which the initial TLE Doppler curve crosses 0 Hz, then
    returns ``delta_t = t_zero_fitted - t_zero_initial`` in seconds.

    A positive value means the fitted curve crosses zero *later* than the
    initial one.  Returns ``None`` if either curve does not cross zero within
    the observation window.
    """
    t_initial = _find_zero_crossing(t_rel, initial_curve)
    t_fitted  = _find_zero_crossing(t_rel, fitted_curve)

    if t_initial is None:
        print("  WARNING: initial TLE curve does not cross 0 Hz in this window; "
              "offset_measurement skipped.")
        return None
    if t_fitted is None:
        print("  WARNING: fitted TLE curve does not cross 0 Hz in this window; "
              "offset_measurement skipped.")
        return None

    delta_t = t_fitted - t_initial
    print(f"  zero-crossing offset : {delta_t:+.2f} s  "
          f"(initial @ {t_initial:.2f} s, fitted @ {t_fitted:.2f} s)")
    return delta_t


def plot_fit(t_rel: np.ndarray, doppler_obs: np.ndarray, fit: FitResult,
             save_path: str | Path | None = None, show: bool = False) -> None:
    """Plot observed vs. initial vs. fitted Doppler curves.

    Calls :func:`offset_measurement` and, if both zero-crossings are found,
    annotates the graph with:

    * A vertical dashed red line at the initial TLE zero-crossing.
    * A vertical dashed blue line at the fitted TLE zero-crossing.
    * A double-headed arrow between the two lines at y = 0 kHz labelled
      with the time offset (e.g. ``Δt = +3.2 s``).
    """
    import matplotlib.pyplot as plt

    from .dsp import _finish_plot

    fig, ax = plt.subplots(figsize=(12, 4))
    ax.plot(t_rel, doppler_obs / 1e3, "k.", markersize=2, label="observed")
    ax.plot(t_rel, fit.initial_curve / 1e3, "r-", linewidth=1, label="initial TLE")
    ax.plot(t_rel, fit.fitted_curve / 1e3, "b-", linewidth=1, label="fitted TLE")

    # --- offset annotation ---------------------------------------------------
    delta_t = offset_measurement(t_rel, fit.initial_curve, fit.fitted_curve)

    if delta_t is not None:
        t_initial = _find_zero_crossing(t_rel, fit.initial_curve)
        t_fitted  = _find_zero_crossing(t_rel, fit.fitted_curve)

        # Vertical dashed lines at each zero-crossing.
        ax.axvline(t_initial, color="red",  linestyle="--", linewidth=0.9,
                   label=f"initial zero @ {t_initial:.1f} s")
        ax.axvline(t_fitted,  color="blue", linestyle="--", linewidth=0.9,
                   label=f"fitted zero  @ {t_fitted:.1f} s")

        if abs(delta_t) > 0:
            # Double-headed arrow between the two crossings at y = 0.
            ax.annotate(
                "",
                xy=(t_fitted, 0), xytext=(t_initial, 0),
                arrowprops=dict(
                    arrowstyle="<->",
                    color="darkgreen",
                    lw=1.5,
                ),
            )
            # Label centred above the arrow.
            label_x = (t_initial + t_fitted) / 2.0
            ax.text(
                label_x, 0,
                f"  \u0394t = {delta_t:+.2f} s",
                color="darkgreen",
                fontsize=8,
                va="bottom",
                ha="center",
            )
        else:
            # Crossings coincide — mark the point.
            ax.plot(t_fitted, 0, "go", markersize=6, label="zero crossings coincide")

    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Doppler shift (kHz)")
    ax.legend(fontsize=8)
    ax.grid(True)
    fig.tight_layout()
    _finish_plot(save_path, show)
