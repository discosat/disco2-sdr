"""Where the TLE comes from: automatic daily download, or a manual file.

Selected by ``[tle] mode`` in config.toml:

``auto``
    Keep a cached copy of the latest TLE downloaded from ``[tle] url``
    (CelesTrak). The copy is re-downloaded once it is older than
    ``refresh_hours`` (default 24). A download is only accepted if it parses
    as a TLE, passes the line checksums and has the expected catalogue number,
    so an error page or a half-finished transfer can never replace a good TLE.
    If the download fails, the last good cached copy keeps being used; if
    there is no cached copy yet, the manual file (``[tle] path``) is used as a
    last resort.

``manual``
    Never touches the network: reads the TLE from ``[tle] path``, exactly as
    before. Edit that file whenever you want to enter a TLE by hand.

The downloaded copy lives in its own file (``cache_path``), so the manual file
is never overwritten.

Check it from the command line (downloads if the cache is stale)::

    python -m doppler_tle.tle_source -c config.toml            # show current TLE
    python -m doppler_tle.tle_source -c config.toml --force    # re-download now
"""

from __future__ import annotations

import os
import re
import sys
import time
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable

from .tle import _parse_blocks, load_tle

# Warn when the TLE being used is older than this: a LEO TLE this old can be
# off by many seconds along-track, which matters for AOS/LOS timing.
STALE_WARN_DAYS = 14.0

_USER_AGENT = "sat-pipeline-tle-updater/1.0 (one request per day)"
_MAX_RESPONSE_BYTES = 64 * 1024


# ---------------------------------------------------------------------------
# TLE text helpers
# ---------------------------------------------------------------------------

def _checksum_ok(line: str) -> bool:
    """TLE line checksum: sum of digits (each '-' counts as 1) modulo 10."""
    if len(line) < 69 or not line[68].isdigit():
        return False
    total = sum(int(c) if c.isdigit() else (1 if c == "-" else 0) for c in line[:68])
    return total % 10 == int(line[68])


def parse_downloaded_tle(text: str, expected_catnr: int | None = None) -> tuple[str, str, str]:
    """Return ``(name, line1, line2)`` from downloaded text, or raise ``ValueError``.

    Strict on purpose: CelesTrak answers "No GP data found" with HTTP 200 for an
    unknown catalogue number, and a truncated transfer would otherwise look
    like a valid file to a lenient parser.
    """
    lines = [ln.rstrip() for ln in text.splitlines() if ln.strip()]
    blocks = _parse_blocks(lines)
    if not blocks:
        snippet = " ".join(text.split())[:80]
        raise ValueError(f"response contains no TLE (got: {snippet!r})")
    name, l1, l2 = blocks[0]
    for label, line in (("line 1", l1), ("line 2", l2)):
        if len(line) < 69:
            raise ValueError(f"TLE {label} is too short ({len(line)} chars)")
        if not _checksum_ok(line):
            raise ValueError(f"TLE {label} fails its checksum")
    if l1[2:7] != l2[2:7]:
        raise ValueError("TLE lines belong to different satellites")
    if expected_catnr is not None and int(l1[2:7]) != expected_catnr:
        raise ValueError(f"TLE is for catalogue number {int(l1[2:7])}, expected {expected_catnr}")
    return name.strip(), l1, l2


def epoch_of(line1: str) -> datetime:
    """UTC epoch encoded in TLE line 1 (two-digit year + fractional day-of-year)."""
    yy = int(line1[18:20])
    year = 2000 + yy if yy < 57 else 1900 + yy
    day_of_year = float(line1[20:32])
    return datetime(year, 1, 1, tzinfo=timezone.utc) + timedelta(days=day_of_year - 1)


def _catnr_from_url(url: str) -> int | None:
    m = re.search(r"CATNR=(\d+)", url, flags=re.IGNORECASE)
    return int(m.group(1)) if m else None


def _download(url: str, timeout_s: float) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout_s) as resp:
        return resp.read(_MAX_RESPONSE_BYTES).decode("ascii", errors="replace")


# ---------------------------------------------------------------------------
# The source
# ---------------------------------------------------------------------------

class TleSource:
    """Hands out the TLE to use right now; refreshes the download when it is due."""

    def __init__(self, mode: str, manual_path: str | Path, manual_index: int = 0,
                 url: str = "", cache_path: str | Path | None = None,
                 refresh_hours: float = 24.0, timeout_s: float = 20.0,
                 retry_minutes: float = 60.0,
                 log: Callable[[str], None] = print) -> None:
        if mode not in ("auto", "manual"):
            raise ValueError(f"[tle] mode must be 'auto' or 'manual', not {mode!r}")
        if mode == "auto" and (not url or not cache_path):
            raise ValueError("[tle] mode = 'auto' needs both 'url' and 'cache_path'")
        self.mode = mode
        self.manual_path = Path(manual_path)
        self.manual_index = manual_index
        self.url = url
        self.cache_path = Path(cache_path) if cache_path else None
        self.refresh_s = refresh_hours * 3600.0
        self.timeout_s = timeout_s
        self.retry_s = retry_minutes * 60.0
        self.log = log
        self._last_attempt: float | None = None   # time.monotonic() of last download try
        self._announced: tuple[str, str] | None = None  # (origin, line1) last logged

    @classmethod
    def from_config(cls, cfg, log: Callable[[str], None] = print) -> "TleSource":
        return cls(cfg.tle_mode, cfg.tle_path, cfg.tle_index, cfg.tle_url,
                   cfg.tle_cache_path or None, cfg.tle_refresh_hours, log=log)

    # -- public ------------------------------------------------------------

    def get(self, force: bool = False) -> tuple[str, str, str]:
        """``(name, line1, line2)`` to use now. Downloads first if the cache is due."""
        if self.mode == "auto":
            self._refresh_cache(force)
        name, l1, l2, origin = self._load_best()
        self._announce(name, l1, origin)
        return name, l1, l2

    # -- download ------------------------------------------------------------

    def _cache_age_s(self) -> float | None:
        try:
            return max(0.0, time.time() - self.cache_path.stat().st_mtime)
        except OSError:
            return None

    def _refresh_cache(self, force: bool) -> None:
        age = self._cache_age_s()
        if not force and age is not None and age < self.refresh_s:
            return  # still fresh
        if (not force and self._last_attempt is not None
                and time.monotonic() - self._last_attempt < self.retry_s):
            return  # failed recently; don't hammer CelesTrak
        self._last_attempt = time.monotonic()
        try:
            text = _download(self.url, self.timeout_s)
            name, l1, l2 = parse_downloaded_tle(text, _catnr_from_url(self.url))
            self._write_cache(name, l1, l2)
            self._last_attempt = None  # the retry gate is for failures only
        except Exception as e:  # noqa: BLE001 — any failure must fall back, never crash
            self.log(f"TLE download failed ({type(e).__name__}: {e}); "
                     f"keeping the previous TLE, will retry in "
                     f"{self.retry_s / 60:.0f} min")

    def _write_cache(self, name: str, l1: str, l2: str) -> None:
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.cache_path.with_name(self.cache_path.name + ".tmp")
        tmp.write_text(f"{name}\n{l1}\n{l2}\n")
        os.replace(tmp, self.cache_path)  # atomic: readers never see half a file

    # -- choosing what to read ---------------------------------------------

    def _load_best(self) -> tuple[str, str, str, str]:
        """Returns (name, line1, line2, origin-description)."""
        if self.mode == "manual":
            name, l1, l2 = load_tle(self.manual_path, self.manual_index)
            return name, l1, l2, f"manual file {self.manual_path.name}"

        try:
            name, l1, l2 = load_tle(self.cache_path, 0)
            return name, l1, l2, f"CelesTrak download ({self.cache_path.name})"
        except (OSError, ValueError, IndexError):
            pass  # no usable cached download yet

        name, l1, l2 = load_tle(self.manual_path, self.manual_index)
        return name, l1, l2, f"manual file {self.manual_path.name} (fallback: no download yet)"

    def _announce(self, name: str, l1: str, origin: str) -> None:
        """Log which TLE is in use, once per change (not on every poll)."""
        key = (origin, l1)
        if key == self._announced:
            return
        self._announced = key
        epoch = epoch_of(l1)
        age_days = (datetime.now(timezone.utc) - epoch).total_seconds() / 86400.0
        self.log(f"TLE in use: {name} from {origin}, "
                 f"epoch {epoch:%Y-%m-%d %H:%M} UTC ({age_days:.1f} days old)")
        if age_days > STALE_WARN_DAYS:
            self.log(f"WARNING: this TLE is {age_days:.0f} days old; AOS/LOS timing "
                     f"may be off by a minute or more")


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> None:
    import argparse

    from .config import load_config

    p = argparse.ArgumentParser(
        prog="doppler_tle.tle_source",
        description="Show the TLE the pipeline would use now (downloading it if it is stale).")
    p.add_argument("-c", "--config", default="config.toml", help="path to config.toml")
    p.add_argument("--force", action="store_true",
                   help="download again now, even if the cached copy is still fresh")
    args = p.parse_args(argv)

    cfg = load_config(args.config)
    source = TleSource.from_config(cfg)
    try:
        name, l1, l2 = source.get(force=args.force)
    except Exception as e:  # noqa: BLE001
        sys.exit(f"ERROR: no usable TLE: {e}")
    print(f"{name}\n{l1}\n{l2}")


if __name__ == "__main__":
    main()
