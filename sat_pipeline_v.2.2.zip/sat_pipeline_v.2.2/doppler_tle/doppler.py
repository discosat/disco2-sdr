"""Doppler extraction: find the satellite's frequency track in a spectrogram."""

from __future__ import annotations

from pathlib import Path

import numpy as np


def find_doppler_peaks(Sxx_db: np.ndarray, freqs: np.ndarray, times: np.ndarray,
                       threshold_db: float, peak_distance: int,
                       freq_range_hz: float,
                       exclude_mask: np.ndarray | None = None,
                       ) -> tuple[np.ndarray, np.ndarray]:
    """Pick the strongest peak in each time slice as the Doppler frequency.

    :param Sxx_db: cleaned spectrogram in dB (from :func:`dsp.clean_spectrogram`)
    :param exclude_mask: optional boolean mask of shape ``(n_freq,)`` produced by
        :func:`dsp.unwanted_signals`.  Bins flagged ``True`` are zeroed out in
        every time slice before peak-finding, so static interferers can never
        be selected as the Doppler peak.
    :returns: ``(times_s, freqs_hz)`` for slices where a peak cleared the threshold.
              ``freqs_hz`` is relative to the carrier.
    """
    from scipy.signal import find_peaks

    f_shifted = np.fft.fftshift(freqs)
    Sxx_shifted = np.fft.fftshift(Sxx_db, axes=0).copy()

    # Apply the static-interference exclusion mask if provided.
    if exclude_mask is not None:
        exclude_shifted = np.fft.fftshift(exclude_mask)
        # Force flagged bins to the global minimum so they can never be chosen.
        Sxx_shifted[exclude_shifted, :] = Sxx_shifted.min()

    noise_floor = np.median(Sxx_shifted)

    det_times, det_freqs = [], []
    for i, t in enumerate(times):
        peaks, props = find_peaks(
            Sxx_shifted[:, i], height=noise_floor + threshold_db, distance=peak_distance,
        )
        # Ignore peaks outside the band of interest.
        in_band = np.abs(f_shifted[peaks]) <= freq_range_hz
        peaks, heights = peaks[in_band], props["peak_heights"][in_band]
        if peaks.size:
            strongest = peaks[np.argmax(heights)]
            det_times.append(t)
            det_freqs.append(f_shifted[strongest])

    times_s, freqs_hz = np.array(det_times), np.array(det_freqs)
    print(f"  detected       : {times_s.size} / {times.size} time slices")
    return times_s, freqs_hz


def save_doppler_csv(path: str | Path, times_s: np.ndarray, freqs_hz: np.ndarray) -> Path:
    """Save detected peaks to a CSV with columns ``time`` (s) and ``frequency`` (Hz)."""
    import pandas as pd

    path = Path(path)
    pd.DataFrame({"time": times_s, "frequency": freqs_hz}).to_csv(path, index=False)
    print(f"  saved          : {path}  ({times_s.size} points)")
    return path


def load_doppler_csv(path: str | Path,
                     recording_start_unix: float = 0.0) -> tuple[np.ndarray, np.ndarray]:
    """Load a Doppler CSV, converting the time column to absolute Unix timestamps."""
    import pandas as pd

    df = pd.read_csv(path)
    return df["time"].values + recording_start_unix, df["frequency"].values


def plot_doppler(Sxx_db: np.ndarray, freqs: np.ndarray, times: np.ndarray,
                 det_times: np.ndarray, det_freqs: np.ndarray, freq_range_hz: float,
                 save_path: str | Path | None = None, show: bool = False) -> None:
    """Plot the spectrogram with the detected Doppler track overlaid."""
    import matplotlib.pyplot as plt

    from .dsp import _finish_plot

    f_shifted = np.fft.fftshift(freqs)
    Sxx_shifted = np.fft.fftshift(Sxx_db, axes=0)
    noise_floor = np.median(Sxx_shifted)
    mask = np.abs(f_shifted) <= freq_range_hz

    plt.figure(figsize=(12, 6))
    plt.pcolormesh(
        times, f_shifted[mask] / 1e3, Sxx_shifted[mask, :],
        shading="nearest", cmap="magma", vmin=noise_floor, vmax=noise_floor + 20,
    )
    plt.plot(det_times, det_freqs / 1e3, "w.", markersize=3, label="detected peaks")
    plt.ylabel("Frequency (kHz relative to carrier)")
    plt.xlabel("Time (s)")
    plt.colorbar(label="Power (dB)")
    plt.legend(loc="upper right")
    plt.tight_layout()
    _finish_plot(save_path, show)
