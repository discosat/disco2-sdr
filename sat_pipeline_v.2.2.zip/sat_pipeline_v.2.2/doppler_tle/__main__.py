"""Command-line entry point:  python -m doppler_tle [options]

Reads conf.toml for all the tuning, and lets you override the common knobs on
the command line. Run with --help to see them.
"""

from __future__ import annotations

import argparse

from . import __version__


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="doppler_tle",
        description="Fit a satellite TLE to a Doppler curve from an SDR recording.",
    )
    p.add_argument("input", nargs="?",
                   help="input file (.raw / _decimated.npz / _spectrogram.npz / _doppler.csv). "
                        "Overrides [recording] input in the config.")
    p.add_argument("-c", "--config", default="conf.toml",
                   help="path to the TOML config (default: conf.toml)")
    p.add_argument("-o", "--output-dir",
                   help="directory for output files (default: next to the input)")
    p.add_argument("--show", action="store_true",
                   help="open plots in a window as well as saving them")
    p.add_argument("--no-optimise", action="store_true",
                   help="stop after extracting the Doppler curve; skip the TLE fit")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)

    # Heavy imports happen here, after --help/--version have had their chance to exit.
    from .config import load_config, validate
    from .pipeline import run

    cfg = load_config(args.config)
    if args.input:
        cfg.input = args.input
    if args.output_dir:
        cfg.output_dir = args.output_dir
    if args.no_optimise:
        cfg.optimise = False

    validate(cfg)
    run(cfg, show=args.show)


if __name__ == "__main__":
    main()
