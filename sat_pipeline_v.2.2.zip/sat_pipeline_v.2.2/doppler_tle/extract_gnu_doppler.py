"""Extract raw IQ data from the raw_data/ folder and write a GNU Radio-compatible
binary file named ``GNU_doppler``.

The output file contains the concatenated complex64 IQ samples from every Gqrx
recording found in raw_data/, in chronological (filename-sorted) order.  It is
written in binary mode so no platform-specific line-ending translation ever
occurs — the file is always UNIX-compatible (no CR bytes).

When called from the pipeline the output path is supplied explicitly (so the
file lands in raw_data/ alongside the other extracted files).  When run as a
standalone script the default location is raw_data/GNU_doppler.

Usage::

    python doppler_tle/extract_gnu_doppler.py

The script can also be imported and its functions called directly.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

# Root of the project: the directory that contains this package.
_PKG_DIR = Path(__file__).parent
_PROJECT_ROOT = _PKG_DIR.parent
_RAW_DATA_DIR = _PROJECT_ROOT / "raw_data"
# Default output: inside raw_data/ alongside the source recordings.
_DEFAULT_OUTPUT = _RAW_DATA_DIR / "GNU_doppler"


def find_raw_files(raw_dir: Path) -> list[Path]:
    """Return all Gqrx ``.raw`` recordings in *raw_dir*, sorted by filename.

    Filenames follow the Gqrx convention::

        gqrx_<YYYYMMDD>_<HHMMSS>_<carrier_hz>_<rate_hz>_fc.raw

    Sorting by name is therefore equivalent to sorting chronologically.
    """
    files = sorted(raw_dir.glob("*_fc.raw"))
    return files


def extract_iq(path: Path) -> np.ndarray:
    """Read one Gqrx ``.raw`` file and return its IQ samples as ``complex64``.

    Gqrx stores raw recordings as a flat stream of interleaved 32-bit float
    I/Q pairs, which is exactly the ``numpy.complex64`` memory layout.
    """
    raw_bytes = path.read_bytes()
    return np.frombuffer(raw_bytes, dtype=np.complex64).copy()


def write_gnu_doppler(iq: np.ndarray, out_path: Path) -> None:
    """Write *iq* (complex64) to *out_path* as a raw binary file.

    The file is opened in binary mode (``'wb'``) so no carriage-return bytes
    are ever inserted, regardless of the host operating system.  The result is
    a UNIX-format GNU Radio File Source compatible stream.
    """
    with out_path.open("wb") as fh:
        iq.tofile(fh)


def run_extraction(raw_dir: Path, out_path: Path) -> Path | None:
    """Core extraction logic used by both the pipeline and standalone entry point.

    Discovers all ``.raw`` files in *raw_dir*, concatenates their IQ samples,
    and writes the result to *out_path*.  Returns *out_path* on success, or
    ``None`` if no recordings were found.
    """
    if not raw_dir.exists():
        print(f"  WARNING: raw_data directory not found at '{raw_dir}'.")
        print("  Create the directory and place Gqrx .raw recordings inside it.")
        return None

    raw_files = find_raw_files(raw_dir)

    if not raw_files:
        print(f"  WARNING: no *_fc.raw files found in '{raw_dir}'.")
        print("  GNU_doppler was NOT written.")
        return None

    print(f"  found {len(raw_files)} recording(s) in '{raw_dir}':")

    pieces: list[np.ndarray] = []
    for path in raw_files:
        iq = extract_iq(path)
        try:
            from .dsp import parse_gqrx_filename
            info = parse_gqrx_filename(path)
            duration_s = iq.size / info.sample_rate_hz
            print(f"    {path.name}  —  {iq.size:,} samples  "
                  f"({duration_s:.2f} s @ {info.sample_rate_hz / 1e6:.3f} MHz)")
        except Exception:
            print(f"    {path.name}  —  {iq.size:,} samples")
        pieces.append(iq)

    combined = np.concatenate(pieces)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    write_gnu_doppler(combined, out_path)

    print(f"  total samples        : {combined.size:,}")
    print(f"  saved                : {out_path}")
    print("  format               : raw complex64, binary, UNIX (no CR bytes)")
    return out_path


def main() -> None:
    """Standalone entry point: extract IQ and write to the default output path."""
    run_extraction(_RAW_DATA_DIR, _DEFAULT_OUTPUT)


if __name__ == "__main__":
    main()
