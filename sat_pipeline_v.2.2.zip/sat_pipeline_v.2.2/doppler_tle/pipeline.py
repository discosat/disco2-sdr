"""Pipeline orchestration: run the five stages, picking the start from the input.

The stage to start at is decided purely by the input file's suffix, so behaviour
is predictable — to re-run from a later stage, just point ``input`` at that
stage's output file:

    .raw              → extract → decimate → spectrogram → doppler → fit
    _decimated.npz    → spectrogram → doppler → fit
    _spectrogram.npz  → doppler → fit
    _doppler.csv      → fit

The ``extract`` stage concatenates all Gqrx .raw recordings in raw_data/ into
a single GNU Radio-compatible binary file (``GNU_doppler``) saved in raw_data/.
It runs only when the pipeline starts from a .raw input.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

from .config import Config

# Stage order and the input suffix that enters at each one.
# 'extract' and 'decimate' both enter on a .raw file; extract always runs first.
STAGES = ["extract", "decimate", "spectrogram", "doppler", "fit"]
_ENTRY_SUFFIX = {
    ".raw": "extract",
    "_decimated.npz": "spectrogram",
    "_spectrogram.npz": "doppler",
    "_doppler.csv": "fit",
}


@dataclass
class Paths:
    decimated: Path
    spectrogram: Path
    spectrogram_png: Path
    doppler_csv: Path
    doppler_png: Path
    fit_png: Path
    gnu_doppler: Path
    freq_log: Path


def _stem(path: Path) -> str:
    name = path.name
    for suffix in _ENTRY_SUFFIX:
        if name.endswith(suffix):
            return name[: -len(suffix)]
    return name


def resolve_paths(cfg: Config) -> Paths:
    """Work out every output path from the input and ``output_dir``."""
    in_path = Path(cfg.input)
    stem = _stem(in_path)

    # The (large) decimated file always sits next to the raw input.
    decimated = in_path.parent / f"{stem}_decimated.npz"

    out_dir = Path(cfg.output_dir) if cfg.output_dir else in_path.parent
    out_dir.mkdir(parents=True, exist_ok=True)
    base = out_dir / stem

    # GNU_doppler lives in the same folder as the .raw source recordings so
    # that all raw/extracted binary data is co-located.
    gnu_doppler = in_path.parent / "GNU_doppler"

    # Sidecar (unix_time, freq_hz) log written by recorder/record_pass.py,
    # if the recording was made with active Doppler retuning. Lives next to
    # the raw input, not in output_dir, since it belongs to that recording.
    freq_log = in_path.parent / f"{stem}_freqlog.csv"

    return Paths(
        decimated=decimated,
        spectrogram=Path(f"{base}_spectrogram.npz"),
        spectrogram_png=Path(f"{base}_spectrogram.png"),
        doppler_csv=Path(f"{base}_doppler.csv"),
        doppler_png=Path(f"{base}_doppler.png"),
        fit_png=Path(f"{base}_fit.png"),
        gnu_doppler=gnu_doppler,
        freq_log=freq_log,
    )


def _entry_stage(cfg: Config) -> str:
    name = Path(cfg.input).name
    for suffix, stage in _ENTRY_SUFFIX.items():
        if name.endswith(suffix):
            return stage
    sys.exit(
        f"ERROR: don't know how to handle '{name}'.\n"
        f"  Input must end in one of: {', '.join(_ENTRY_SUFFIX)}"
    )


def run(cfg: Config, show: bool = False) -> None:
    """Run the pipeline from the stage implied by ``cfg.input`` through to the end."""
    if not show:
        import matplotlib
        matplotlib.use("Agg")  # headless: save figures, never block on a window

    paths = resolve_paths(cfg)
    start = _entry_stage(cfg)
    todo = STAGES[STAGES.index(start):]

    print(f"Input : {cfg.input}")
    print(f"Stages: {' → '.join(todo)}")
    print(f"Output: {paths.spectrogram.parent}\n")

    if "extract" in todo:
        _extract(cfg, paths)
    if "decimate" in todo:
        _decimate(cfg, paths)
    if "spectrogram" in todo:
        _spectrogram(cfg, paths, show)
    if "doppler" in todo:
        _doppler(cfg, paths, show)
    if "fit" in todo:
        if cfg.optimise:
            _fit(cfg, paths, show)
        else:
            print("[5/5] fit — skipped ([optimiser] enabled = false)")

    print("\nDone.")


# ---------------------------------------------------------------------------
# Stages (heavy imports kept local so `--help` works without the sci stack)
# ---------------------------------------------------------------------------

def _extract(cfg: Config, paths: Paths) -> None:
    from .extract_gnu_doppler import run_extraction
    print("[1/5] extract")
    raw_dir = Path(cfg.input).parent
    run_extraction(raw_dir, paths.gnu_doppler)


def _decimate(cfg: Config, paths: Paths) -> None:
    from . import dsp
    print("[2/5] decimate")
    dsp.decimate_raw(cfg.input, paths.decimated, cfg.decimate_factors, cfg.chunk_seconds)


def _spectrogram(cfg: Config, paths: Paths, show: bool) -> None:
    from . import dsp
    print("[3/5] spectrogram")
    iq, sample_rate, carrier = dsp.load_decimated(paths.decimated)
    Sxx, freqs, times = dsp.make_spectrogram(iq, sample_rate, cfg.nperseg, cfg.average)
    dsp.save_spectrogram(paths.spectrogram, Sxx, freqs, times, carrier)
    dsp.plot_spectrogram(dsp.clean_spectrogram(Sxx), freqs, times, carrier,
                         cfg.freq_range_hz, save_path=paths.spectrogram_png, show=show)


def _doppler(cfg: Config, paths: Paths, show: bool) -> None:
    from . import doppler, dsp
    print("[4/5] doppler")
    Sxx, freqs, times, _ = dsp.load_spectrogram(paths.spectrogram)
    Sxx_db = dsp.clean_spectrogram(Sxx)
    # Detect static interferers on the raw (linear) spectrogram and pass the
    # exclusion mask into peak-finding so they are never chosen as Doppler peaks.
    exclude_mask = dsp.unwanted_signals(Sxx, freqs, cfg.static_ratio_threshold)
    det_times, det_freqs = doppler.find_doppler_peaks(
        Sxx_db, freqs, times, cfg.threshold_db, cfg.peak_distance, cfg.freq_range_hz,
        exclude_mask=exclude_mask)

    # If the recording was made with active Doppler retuning, det_freqs is
    # only the residual relative to a moving SDR tuning, not the true
    # Doppler shift. Add the tuning offset back in before saving anything,
    # so the CSV/plot/fit downstream all see the true, physical curve.
    if paths.freq_log.exists():
        from . import freqlog
        info = dsp.parse_gqrx_filename(cfg.input)
        det_times_unix = det_times + info.start_unix
        det_freqs = freqlog.compensate(
            det_times_unix, det_freqs, paths.freq_log, cfg.transmit_freq_mhz * 1e6)
        print(f"  freq log       : {paths.freq_log.name} (compensated for active retuning)")
    else:
        print("  freq log       : none found — assuming fixed-frequency recording")

    doppler.save_doppler_csv(paths.doppler_csv, det_times, det_freqs)
    doppler.plot_doppler(Sxx_db, freqs, times, det_times, det_freqs, cfg.freq_range_hz,
                         save_path=paths.doppler_png, show=show)


def _fit(cfg: Config, paths: Paths, show: bool) -> None:
    from skyfield.api import load, wgs84

    from . import doppler, dsp, tle
    from .tle_source import TleSource
    print("[5/5] fit")

    # Every stage's filename keeps the gqrx_<date>_<time>_… prefix, so the
    # recording start time can be read straight from the input name.
    info = dsp.parse_gqrx_filename(cfg.input)
    timestamps, doppler_obs = doppler.load_doppler_csv(paths.doppler_csv, info.start_unix)
    carrier_hz = cfg.transmit_freq_mhz * 1e6

    gs = wgs84.latlon(cfg.gs_latitude, cfg.gs_longitude, elevation_m=cfg.gs_elevation_m)
    ts = load.timescale()

    # Same source the scheduler uses: in auto mode this is the cached CelesTrak
    # download (refreshed only if older than refresh_hours), in manual mode the
    # TLE file. It never aborts the fit over a failed download.
    name, l1, l2 = TleSource.from_config(cfg, log=lambda m: print(f"  {m}")).get()
    print(f"  satellite      : {name}")
    print(f"  duration       : {timestamps[-1] - timestamps[0]:.0f} s")
    print(f"  observed       : {doppler_obs.min() / 1e3:.2f} … {doppler_obs.max() / 1e3:.2f} kHz")

    result = tle.fit_tle(name, l1, l2, cfg.optimise_params, gs, ts,
                         timestamps, doppler_obs, carrier_hz)

    print(f"\n  success        : {result.success} ({result.message})")
    for p, before, after in zip(result.param_names, result.initial_params, result.fitted_params):
        print(f"    {p:<22}: {before:.6f} → {after:.6f}  (Δ {after - before:+.6f})")
    print(f"  cost           : {result.initial_cost:.1f} → {result.final_cost:.1f}")
    print(f"\n  fitted TLE:\n  {result.fitted_l1}\n  {result.fitted_l2}")

    tle.plot_fit(timestamps - timestamps[0], doppler_obs, result,
                 save_path=paths.fit_png, show=show)
