"""Compensate for active Doppler retuning during recording.

Background
----------
The recorder (``recorder/record_pass.py``) keeps the SDR roughly centred on
the satellite's downlink throughout a pass by continuously retuning it to a
Doppler-corrected frequency supplied by Gpredict via rigctld. Every retune is
logged to a CSV sidecar file next to the raw IQ recording, as
``(unix_time, freq_hz)`` pairs, roughly once a second.

Because of that retuning, the peak frequency the analysis pipeline finds in
the spectrogram is relative to *whatever the SDR happened to be tuned to at
that instant* - not the satellite's true Doppler shift relative to a fixed
carrier. This module adds the tuning offset back in so the rest of the
pipeline (CSV output, plots, TLE fit) sees the true, physical Doppler curve
exactly as if the recording had been made at a single fixed frequency:

    true_doppler(t) = detected_relative_freq(t) + tuned_freq(t) - transmit_freq_hz

If Gpredict wasn't actually connected during the pass, ``tuned_freq(t)``
never moves away from the recorder's default frequency, and the formula
above simply reduces to ``detected_relative_freq(t)`` unchanged - i.e. this
degrades gracefully to the fixed-frequency case rather than corrupting the
curve.

The lookup is a zero-order hold (the most recent retune at or before each
query time), not interpolation: a retune is a discrete event, not a sample
of a continuous signal, so there is nothing to interpolate between.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

__all__ = ["load_freq_log", "tuned_freq_at", "compensate"]


def load_freq_log(path: str | Path) -> tuple[np.ndarray, np.ndarray]:
    """Load a ``(unix_time, freq_hz)`` sidecar CSV.

    Returns ``(log_times, log_freqs)``, both float/int numpy arrays sorted
    by time.
    """
    df = pd.read_csv(path)
    if not {"unix_time", "freq_hz"}.issubset(df.columns):
        raise ValueError(
            f"{path}: expected columns 'unix_time,freq_hz', got {list(df.columns)}"
        )
    df = df.sort_values("unix_time")
    log_times = df["unix_time"].to_numpy(dtype=float)
    log_freqs = df["freq_hz"].to_numpy(dtype=float)
    if len(log_times) == 0:
        raise ValueError(f"{path}: freq log is empty")
    return log_times, log_freqs


_BOUNDARY_EPS_S = 1e-3  # << retune granularity (~1s), >> float64 noise at Unix-epoch magnitude


def tuned_freq_at(
    query_times: np.ndarray, log_times: np.ndarray, log_freqs: np.ndarray
) -> np.ndarray:
    """Zero-order-hold lookup: the tuned frequency in effect at each query time.

    For a query time before the first log entry, the first logged frequency
    is used (the recorder logs its startup value before the first real
    rigctld poll, so this only matters for the first fraction of a second).

    A small epsilon is subtracted from the query times before searching.
    Without it, a query time built as ``start_unix + small_offset`` can round
    to land exactly on (or past) a log entry it was meant to fall just short
    of - float64 has ~15-17 significant digits, and start_unix alone already
    uses ~10 of them, so the sub-second offset that matters here can lose
    precision. That silently picks the next retune's frequency one sample
    early. The epsilon is far smaller than the ~1s retune granularity, so it
    cannot affect any genuine (non-boundary-adjacent) lookup.
    """
    idx = np.searchsorted(log_times, np.asarray(query_times) - _BOUNDARY_EPS_S, side="right") - 1
    idx = np.clip(idx, 0, len(log_freqs) - 1)
    return log_freqs[idx]


def compensate(
    det_times_unix: np.ndarray,
    det_freqs_relative: np.ndarray,
    freq_log_path: str | Path,
    transmit_freq_hz: float,
) -> np.ndarray:
    """Reconstruct the true Doppler shift (Hz) for each detected peak.

    Parameters
    ----------
    det_times_unix:
        Absolute Unix timestamp of each detected peak (recording start time
        plus the spectrogram's relative time axis).
    det_freqs_relative:
        Detected peak frequency (Hz), relative to whatever the SDR was
        tuned to at that instant - i.e. the raw output of
        :func:`doppler_tle.doppler.find_doppler_peaks`.
    freq_log_path:
        Path to the sidecar CSV written by ``recorder/record_pass.py``.
    transmit_freq_hz:
        The satellite's nominal transmit frequency (``transmit_freq_mhz``
        from config, in Hz).

    Returns
    -------
    numpy.ndarray
        The reconstructed true Doppler shift (Hz), same shape as
        ``det_freqs_relative``.
    """
    log_times, log_freqs = load_freq_log(freq_log_path)
    tuned = tuned_freq_at(np.asarray(det_times_unix, dtype=float), log_times, log_freqs)
    return np.asarray(det_freqs_relative, dtype=float) + tuned - float(transmit_freq_hz)
