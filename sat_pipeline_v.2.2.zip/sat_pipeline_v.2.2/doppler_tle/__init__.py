"""
doppler_tle — fit a satellite TLE to a Doppler curve measured from an SDR recording.

The pipeline has four stages, each consuming the previous one's output:

    .raw  ──decimate──▶  _decimated.npz  ──spectrogram──▶  _spectrogram.npz
          ──doppler──▶  _doppler.csv  ──fit──▶  optimised TLE (+ plots)

Run it with:  python -m doppler_tle
Configure it in:  conf.toml
"""

__version__ = "1.0.0"
