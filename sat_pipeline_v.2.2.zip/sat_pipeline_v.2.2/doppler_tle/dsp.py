"""Signal processing: raw IQ → decimated IQ → spectrogram.

Input is a Gqrx ``.raw`` recording whose filename encodes the capture metadata:

    gqrx_<YYYYMMDD>_<HHMMSS>_<carrier_freq_hz>_<sample_rate_hz>_fc.raw
"""

from __future__ import annotations

import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


# ---------------------------------------------------------------------------
# Gqrx filename metadata
# ---------------------------------------------------------------------------

class RecordingInfo:
    """Metadata parsed from a Gqrx filename."""

    def __init__(self, start_unix: float, carrier_freq_hz: float, sample_rate_hz: float):
        self.start_unix = start_unix
        self.carrier_freq_hz = carrier_freq_hz
        self.sample_rate_hz = sample_rate_hz


def parse_gqrx_filename(path: str | Path) -> RecordingInfo:
    """Extract capture time, carrier frequency and sample rate from a Gqrx filename."""
    parts = Path(path).name.split("_")
    try:
        dt = datetime.strptime(f"{parts[1]}_{parts[2]}", "%Y%m%d_%H%M%S")
        dt = dt.replace(tzinfo=timezone.utc)
        return RecordingInfo(
            start_unix=dt.timestamp(),
            carrier_freq_hz=float(parts[3]),
            sample_rate_hz=float(parts[4]),
        )
    except (IndexError, ValueError) as e:
        raise ValueError(
            f"Could not parse Gqrx metadata from '{Path(path).name}'. "
            f"Expected gqrx_<date>_<time>_<carrier>_<rate>_fc.raw"
        ) from e


# ---------------------------------------------------------------------------
# Decimation
# ---------------------------------------------------------------------------

def decimate_iq(chunk: np.ndarray, factors: list[int]) -> np.ndarray:
    """Downsample complex IQ by applying ``factors`` in sequence.

    Each factor is applied to the I and Q components separately (so the two are
    never mixed) and in turn, e.g. ``[5, 5]`` decimates by a total of 25.
    Several small steps are numerically kinder than one large factor.
    """
    from scipy.signal import decimate

    real, imag = chunk.real, chunk.imag
    for q in factors:
        real = decimate(real, q)
        imag = decimate(imag, q)
    return (real + 1j * imag).astype(np.complex64)


def decimate_raw(raw_path: str | Path, out_path: str | Path,
                 factors: list[int], chunk_seconds: float) -> Path:
    """Read a Gqrx ``.raw`` file in chunks, decimate each, and save ``out_path`` (.npz).

    Only one chunk is held in memory at a time, so this stays RAM-safe on large
    recordings.
    """
    raw_path, out_path = Path(raw_path), Path(out_path)
    info = parse_gqrx_filename(raw_path)
    total_factor = math.prod(factors)
    out_rate = info.sample_rate_hz / total_factor

    chunk_samples = int(info.sample_rate_hz * chunk_seconds)
    chunk_bytes = chunk_samples * np.dtype(np.complex64).itemsize
    file_size = raw_path.stat().st_size
    n_chunks = file_size // chunk_bytes

    print(f"  sample rate    : {info.sample_rate_hz:,.0f} Hz → {out_rate:,.0f} Hz "
          f"(÷{total_factor}, factors={factors})")
    print(f"  carrier        : {info.carrier_freq_hz / 1e6:.3f} MHz")
    print(f"  chunks         : {n_chunks} × {chunk_seconds:g} s")

    if n_chunks == 0:
        raise ValueError(
            f"Recording is shorter than one {chunk_seconds:g}s chunk "
            f"({file_size} bytes). Lower [decimation] chunk_seconds."
        )

    pieces = []
    with raw_path.open("rb") as f:
        for i in range(n_chunks):
            f.seek(i * chunk_bytes)
            chunk = np.frombuffer(f.read(chunk_bytes), dtype=np.complex64).copy()
            pieces.append(decimate_iq(chunk, factors))
            print(f"    chunk {i + 1}/{n_chunks}", end="\r", flush=True)
    print()

    iq = np.concatenate(pieces)
    np.savez(out_path, iq=iq, sample_rate=out_rate, carrier_freq=info.carrier_freq_hz)
    print(f"  saved          : {out_path}  ({iq.size:,} samples)")
    return out_path


def load_decimated(path: str | Path) -> tuple[np.ndarray, float, float]:
    """Load a ``_decimated.npz`` → (iq, sample_rate_hz, carrier_freq_hz)."""
    data = np.load(path)
    return data["iq"], float(data["sample_rate"]), float(data["carrier_freq"])


# ---------------------------------------------------------------------------
# Spectrogram
# ---------------------------------------------------------------------------

def make_spectrogram(iq: np.ndarray, sample_rate: float,
                     nperseg: int, average: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Time-averaged power spectrogram (Hamming window, 75% overlap).

    Returns ``(Sxx, freqs, times)`` where ``Sxx`` is linear power of shape
    ``(nperseg, n_time)``; frequency resolution is ``sample_rate / nperseg``.
    Time bins are averaged in groups of ``average`` to raise SNR.
    """
    from scipy.signal import spectrogram

    freqs, times, Sxx = spectrogram(
        iq, fs=sample_rate, nperseg=nperseg, noverlap=int(nperseg * 0.75),
        window="hamming", return_onesided=False,
    )

    n = (Sxx.shape[1] // average) * average
    Sxx_avg = Sxx[:, :n].reshape(Sxx.shape[0], -1, average).mean(axis=2)
    return Sxx_avg, freqs, times[:n:average]


def clean_spectrogram(Sxx: np.ndarray) -> np.ndarray:
    """Convert to dB and remove static features, leaving transient signals.

    Subtracts the per-frequency mean (kills signals continuous in time, e.g.
    fixed carriers) then the per-time median (kills broadband noise bursts).
    A satellite's sweeping Doppler curve survives both. Returns dB.
    """
    db = 10 * np.log10(Sxx + 1e-12)
    db = db - db.mean(axis=1, keepdims=True)        # kill time-continuous signals
    db = db - np.median(db, axis=0, keepdims=True)  # kill broadband bursts
    return db


def save_spectrogram(path: str | Path, Sxx: np.ndarray, freqs: np.ndarray,
                     times: np.ndarray, carrier_freq: float) -> Path:
    """Save the raw (linear) spectrogram and its axes to ``path`` (.npz)."""
    path = Path(path)
    np.savez(
        path,
        Sxx=np.asarray(Sxx, dtype=np.float32),
        f=np.asarray(freqs, dtype=np.float64),
        t=np.asarray(times, dtype=np.float64),
        carrier_freq=np.float64(carrier_freq),
    )
    print(f"  saved          : {path}")
    return path


def load_spectrogram(path: str | Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    """Load a ``_spectrogram.npz`` → (Sxx, freqs, times, carrier_freq_hz)."""
    data = np.load(path)
    return data["Sxx"], data["f"], data["t"], float(data["carrier_freq"])


def plot_spectrogram(Sxx_db: np.ndarray, freqs: np.ndarray, times: np.ndarray,
                     carrier_freq: float, freq_range_hz: float,
                     save_path: str | Path | None = None, show: bool = False) -> None:
    """Plot a cleaned (dB) spectrogram centred on the carrier frequency."""
    import matplotlib.pyplot as plt

    noise_floor = np.median(Sxx_db)
    f_shifted = np.fft.fftshift(freqs)
    mask = np.abs(f_shifted) <= freq_range_hz

    plt.figure(figsize=(12, 6))
    plt.pcolormesh(
        times, f_shifted[mask] / 1e3, np.fft.fftshift(Sxx_db, axes=0)[mask, :],
        shading="nearest", cmap="magma", vmin=noise_floor, vmax=noise_floor + 20,
    )
    plt.ylabel("Frequency (kHz relative to carrier)")
    plt.xlabel("Time (s)")
    plt.title(f"Carrier: {carrier_freq / 1e6:.3f} MHz")
    plt.colorbar(label="Power (dB)")
    plt.tight_layout()
    _finish_plot(save_path, show)


# ---------------------------------------------------------------------------
# Static interference detection
# ---------------------------------------------------------------------------

def unwanted_signals(Sxx: np.ndarray, freqs: np.ndarray,
                     threshold: float = 10.0) -> np.ndarray:
    """Detect frequency bins occupied by static (non-satellite) interference.

    Signals that do not belong to the satellite almost always remain fixed at a
    single frequency throughout the pass.  Their key property is that their
    power is consistently high across time — high mean, low temporal variance.

    The function computes a *mean-to-std ratio* for each frequency bin.  Bins
    whose ratio exceeds *threshold* **and** whose mean power is above the
    overall median noise level are flagged as static interferers.

    :param Sxx: Linear-power spectrogram of shape ``(n_freq, n_time)`` (the
        raw, un-cleaned array saved in ``_spectrogram.npz``).
    :param freqs: Frequency axis (Hz, relative to carrier) of length
        ``n_freq``, as returned by :func:`load_spectrogram`.
    :param threshold: Mean/std ratio above which a bin is classified as a
        static interferer.  Higher values = stricter (fewer bins flagged).
        The default of 10.0 works well for typical SDR recordings.
    :returns: Boolean mask of shape ``(n_freq,)`` — ``True`` marks bins to
        **exclude** from Doppler peak extraction.
    """
    epsilon = 1e-12
    mean_power = Sxx.mean(axis=1)            # shape (n_freq,)
    std_power  = Sxx.std(axis=1)             # shape (n_freq,)
    ratio      = mean_power / (std_power + epsilon)

    noise_floor = np.median(mean_power)
    exclude = (ratio > threshold) & (mean_power > noise_floor)

    n_flagged = int(exclude.sum())
    if n_flagged:
        f_shifted = np.fft.fftshift(freqs)
        flagged_khz = f_shifted[np.fft.fftshift(exclude)] / 1e3
        freqs_str = ", ".join(f"{f:+.2f} kHz" for f in flagged_khz)
        print(f"  unwanted_signals : {n_flagged} static bin(s) flagged — {freqs_str}")
    else:
        print("  unwanted_signals : no static interferers detected")

    return exclude


def _finish_plot(save_path, show) -> None:
    """Save and/or show the current matplotlib figure, then close it."""
    import matplotlib.pyplot as plt

    if save_path:
        plt.savefig(save_path, dpi=300)
        print(f"  plot           : {save_path}")
    if show:
        plt.show()
    plt.close()
