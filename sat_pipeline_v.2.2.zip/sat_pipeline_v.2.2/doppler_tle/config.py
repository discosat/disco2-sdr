"""Configuration loading.

All tuning lives in a TOML file (see conf.toml). This module reads it into a
single flat :class:`Config` object with sensible defaults, so the rest of the
code never touches raw dictionaries and the CLI can override any field.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:  # pragma: no cover
    try:
        import tomli as tomllib  # type: ignore
    except ModuleNotFoundError:
        sys.exit(
            "ERROR: need TOML support.\n"
            "  Python >= 3.11 has it built in (check your interpreter),\n"
            "  Python <  3.11: run  pip install tomli"
        )


@dataclass
class Config:
    """Everything the pipeline needs, in one flat object."""

    # --- recording ---
    input: str = ""                      # .raw / _decimated.npz / _spectrogram.npz / _doppler.csv
    output_dir: str = ""                 # blank = write outputs next to the input
    transmit_freq_mhz: float = 437.075   # satellite transmit frequency

    # --- ground station ---
    gs_name: str = "ground station"
    gs_latitude: float = 0.0             # degrees N
    gs_longitude: float = 0.0            # degrees E
    gs_elevation_m: float = 0.0          # metres above sea level

    # --- TLE ---
    # "manual" = read tle_path; "auto" = download daily from tle_url into
    # tle_cache_path (tle_path is then only the fallback). See tle_source.py.
    # The default stays "manual" so a config.toml without these keys behaves
    # exactly as before.
    tle_mode: str = "manual"
    tle_path: str = "disco-2.tle"        # the manually-entered TLE file
    tle_index: int = 0                   # which block of tle_path to use (0 = first)
    tle_url: str = ""                    # CelesTrak URL (auto mode)
    tle_cache_path: str = ""             # where the downloaded TLE is kept (auto mode)
    tle_refresh_hours: float = 24.0      # re-download when the cached copy is older than this

    # --- decimation ---
    decimate_factors: list[int] = field(default_factory=lambda: [5, 5])
    chunk_seconds: float = 30.0          # how much IQ to load at once (lower if low on RAM)

    # --- spectrogram ---
    nperseg: int = 4096                  # FFT size (power of 2)
    average: int = 25                    # time slices averaged together (higher = better SNR)
    freq_range_hz: float = 20_000.0      # half-width of the band to display/search

    # --- doppler ---
    threshold_db: float = 14.5           # peak height above noise floor
    peak_distance: int = 25              # min separation between peaks, in frequency bins
    static_ratio_threshold: float = 10.0 # mean/std ratio above which a bin is a static interferer

    # --- optimiser ---
    optimise: bool = True
    optimise_params: list[str] = field(default_factory=lambda: ["epoch", "raan"])


# Maps TOML "section.key" -> Config field name. Anything not listed is ignored.
_MAPPING = {
    ("recording", "input"): "input",
    ("recording", "output_dir"): "output_dir",
    ("recording", "transmit_freq_mhz"): "transmit_freq_mhz",
    ("ground_station", "name"): "gs_name",
    ("ground_station", "latitude"): "gs_latitude",
    ("ground_station", "longitude"): "gs_longitude",
    ("ground_station", "elevation_m"): "gs_elevation_m",
    ("tle", "mode"): "tle_mode",
    ("tle", "path"): "tle_path",
    ("tle", "index"): "tle_index",
    ("tle", "url"): "tle_url",
    ("tle", "cache_path"): "tle_cache_path",
    ("tle", "refresh_hours"): "tle_refresh_hours",
    ("decimation", "factors"): "decimate_factors",
    ("decimation", "chunk_seconds"): "chunk_seconds",
    ("spectrogram", "nperseg"): "nperseg",
    ("spectrogram", "average"): "average",
    ("spectrogram", "freq_range_hz"): "freq_range_hz",
    ("doppler", "threshold_db"): "threshold_db",
    ("doppler", "peak_distance"): "peak_distance",
    ("doppler", "static_ratio_threshold"): "static_ratio_threshold",
    ("optimiser", "enabled"): "optimise",
    ("optimiser", "params"): "optimise_params",
}


def load_config(path: str | Path) -> Config:
    """Read ``path`` (a TOML file) into a :class:`Config`, applying defaults."""
    path = Path(path)
    if not path.exists():
        sys.exit(f"ERROR: config file not found: {path}")

    with path.open("rb") as f:
        data = tomllib.load(f)

    values: dict = {}
    for (section, key), field_name in _MAPPING.items():
        if section in data and key in data[section]:
            values[field_name] = data[section][key]

    cfg = Config(**values)

    # TLE paths are relative to the config file, not the current directory, so
    # `python -m doppler_tle` and scheduler.py find the same files from anywhere.
    for attr in ("tle_path", "tle_cache_path"):
        value = getattr(cfg, attr)
        if value and not Path(value).is_absolute():
            setattr(cfg, attr, str(path.parent / value))
    return cfg


def validate(cfg: Config) -> None:
    """Fail early with a clear message if the config is unusable."""
    if not cfg.input:
        sys.exit("ERROR: no input file set. Put a path in conf.toml ([recording] input) "
                 "or pass one on the command line.")
    if cfg.tle_mode not in ("auto", "manual"):
        sys.exit(f"ERROR: [tle] mode must be \"auto\" or \"manual\", not {cfg.tle_mode!r}.")
    if cfg.tle_mode == "auto" and not (cfg.tle_url and cfg.tle_cache_path):
        sys.exit("ERROR: [tle] mode = \"auto\" needs both `url` and `cache_path`.")
    bad = [p for p in cfg.optimise_params if p not in _TLE_FIELDS]
    if bad:
        sys.exit(f"ERROR: unknown optimiser params {bad}.\n  Valid choices: {sorted(_TLE_FIELDS)}")


# TLE fields that may be optimised (kept here to validate config without importing tle.py,
# which pulls in numpy/skyfield).
_TLE_FIELDS = {
    "epoch", "inclination", "raan", "eccentricity", "arg_of_perigee",
    "mean_anomaly", "mean_motion", "first_div_mean_motion",
    "second_div_mean_motion", "drag_term",
}
